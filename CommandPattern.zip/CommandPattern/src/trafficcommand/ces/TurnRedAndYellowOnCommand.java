/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TurnRedAndYellowOnCommand implements Command {
	private TrafficLights trafficLights;

	public TurnRedAndYellowOnCommand(TrafficLights trafficLights) {
		this.trafficLights = trafficLights;
	}

	@Override
	public void execute() {
		trafficLights.setGreen(false);
		trafficLights.setRed(true);
		trafficLights.setYellow(true);
	}

}
