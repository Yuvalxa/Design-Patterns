/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TurnRedOnCommand implements Command{
	private TrafficLights trafficLights;
	
	
	public TurnRedOnCommand(TrafficLights trafficLights) {
		this.trafficLights = trafficLights;
	}


	@Override
	public void execute() {
		trafficLights.setRed(true);
		trafficLights.setYellow(false);
		trafficLights.setGreen(false);
	}
	
}
