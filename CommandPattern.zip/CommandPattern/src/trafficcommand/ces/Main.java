/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class Main {
	public static void main(String[] args) {
		TrafficController traffic = new TrafficController();
		System.out.println(traffic);

		traffic.turnRedOn();

		traffic.turnRedAndYellowOn();

		traffic.turnGreenOn();

	}
}
