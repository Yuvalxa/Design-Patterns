/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TrafficController {
	private TrafficLights trafficLights;
	private Command rCommand;
	private Command yCommand;
	private Command gCommand;
	private Command ryCommand;

	public TrafficController() {
		this.trafficLights = new TrafficLights();
		this.rCommand = new TurnRedOnCommand(trafficLights);
		this.ryCommand = new TurnRedAndYellowOnCommand(trafficLights);
		this.yCommand = new TurnYellowOnCommand(trafficLights);
		this.gCommand = new TurnGreenOnCommand(trafficLights);
	}

	public void turnRedOn() {
		rCommand.execute();
		System.out.println(toString());
	}

	public void turnRedAndYellowOn() {
		ryCommand.execute();
		System.out.println(toString());

	}

	public void turnYellowOn() {
		yCommand.execute();
		System.out.println(toString());

	}

	public void turnGreenOn() {
		gCommand.execute();
		System.out.println(toString());

	}

	@Override
	public String toString() {
		return trafficLights.toString();
	}

}
