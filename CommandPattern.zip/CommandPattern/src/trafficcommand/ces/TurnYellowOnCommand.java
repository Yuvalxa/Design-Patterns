/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TurnYellowOnCommand implements Command{
	private TrafficLights trafficLights;
	
	
	public TurnYellowOnCommand(TrafficLights trafficLights) {
		this.trafficLights = trafficLights;
	}


	@Override
	public void execute() {
		trafficLights.setRed(false);
		trafficLights.setGreen(false);
		trafficLights.setYellow(true);
	}
	
}
