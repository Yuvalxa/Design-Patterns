/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TrafficLights {
	private boolean isRed;
	private boolean isYellow;
	private boolean isGreen;

	public void TrafficLight() {
	}

	public boolean isRed() {
		return isRed;
	}

	public void setRed(boolean isRed) {
		this.isRed = isRed;
	}

	public boolean isYellow() {
		return isYellow;
	}

	public void setYellow(boolean isYellow) {
		this.isYellow = isYellow;
	}

	public boolean isGreen() {
		return isGreen;
	}

	public void setGreen(boolean isGreen) {
		this.isGreen = isGreen;
	}

	@Override
	public String toString() {
		return "TrafficLights:\n---\n" + (isRed ? "|*|" : "| |") + "\n---\n" + (isYellow ? "|*|" : "| |") + "\n---\n"
				+ (isGreen ? "|*|" : "| |") + "\n---\n";
	}
}