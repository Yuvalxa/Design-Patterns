/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public interface Command {
	void execute();
}
