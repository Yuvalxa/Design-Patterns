/**
 *@author Grigory Shaulov
 */
package trafficcommand.ces;

public class TurnGreenOnCommand implements Command{
	private TrafficLights trafficLights;
	
	
	public TurnGreenOnCommand(TrafficLights trafficLights) {
		this.trafficLights = trafficLights;
	}


	@Override
	public void execute() {
		trafficLights.setRed(false);
		trafficLights.setYellow(false);
		trafficLights.setGreen(true);
	}
	
}
