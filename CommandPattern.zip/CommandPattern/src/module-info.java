module CommandPattern {
}