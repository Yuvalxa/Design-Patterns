module StrategyPattern {
}