package Book;

public class StrategyUpperCase implements StrategyInterFace{

	@Override
	public String format(Book book) {
	 		return book.getTitle().toUpperCase();

	}

}
