package Book;

public class Context {
	private StrategyInterFace strategy;

	public Context(StrategyInterFace strategy) {
		this.strategy = strategy;
	}
	public String setCase(Book book) {
		return this.strategy.format(book);
	}
}
