package Book;

public class StrategyLowerCase implements StrategyInterFace {

	@Override
	public String format(Book book) {
		return book.getTitle().toLowerCase();
	}

}
