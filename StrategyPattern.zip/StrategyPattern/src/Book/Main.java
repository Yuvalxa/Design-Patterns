package Book;

public class Main {
public static void main(String[] args) {
Book book = new Book("Strategy Pattern");
book.setContent("In computer programming, the strategy pattern is abehavioral software design pattern that enables selecting an algorithm atruntime.\\n\"�.\\n\");\r\n");
StrategyUpperCase s1 = new StrategyUpperCase();
StrategyLowerCase s2 = new StrategyLowerCase();

Context t1 = new Context(s1);
Context t2 = new Context(s2);

System.out.println("Title: " + book.getTitle());
System.out.println("Title in uppercase: " + t1.setCase(book));
System.out.println(book);
System.out.println("Title in lowercase: " + t2.setCase(book));
System.out.println(book);
}
}
