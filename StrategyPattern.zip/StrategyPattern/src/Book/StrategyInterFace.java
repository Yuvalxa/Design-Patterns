package Book;

public interface StrategyInterFace {
	 String format(Book book);
}
