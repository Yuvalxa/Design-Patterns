package Book;

public class Book {
	private String title;
	private String content;
	public Book(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}


	@Override
	public String toString() {
		return String.format("\nBook: %s\n\n%s\n", title, content);
	}
}
