package ICar;

final public class Sedan extends Vehicle {

	public Sedan(String brand, String serial) {
		super(brand, serial);
	}

	@Override
	public void printICar() {
		System.out.println(this.getClass().getSimpleName() + " " + getBrand() + " " + getSerial());
	}
}
