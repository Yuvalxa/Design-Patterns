package ICar;

public class Main {

	public static void main(String[] args) {

		ICar carSedan = new Sedan("BMW", "M5");
		carSedan.printICar();

		ICar carLimousine = new Limousine("HUMMER", "H2");
		carLimousine.printICar();

		ICar carExclusive = new Exclusive("Excalibur", "Phantom");
		carExclusive.printICar();

		ICar carSUV = new SUV("JEEP", "GRAND CHEROKEE");
		carSUV.printICar();

		ICar carMinibus = new Minibus("Mercedes", "Sprinter 907");

		carMinibus.printICar();

	}

}
