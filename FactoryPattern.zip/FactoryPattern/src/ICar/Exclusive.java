package ICar;

final public class Exclusive extends Vehicle {

	public Exclusive(String brand, String serial) {
		super(brand, serial);
	}

	@Override
	public void printICar() {
		System.out.println(this.getClass().getSimpleName() + " " + getBrand() + " " + getSerial());
	}
}
