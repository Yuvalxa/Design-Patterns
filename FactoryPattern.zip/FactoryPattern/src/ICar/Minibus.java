package ICar;

final public class Minibus extends Vehicle {

	public Minibus(String brand, String serial) {
		super(brand, serial);
	}

	@Override
	public void printICar() {
		System.out.println(this.getClass().getSimpleName() + " " + getBrand() + " " + getSerial());
	}
}