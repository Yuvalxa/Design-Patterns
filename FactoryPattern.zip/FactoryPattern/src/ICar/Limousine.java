package ICar;

final public class Limousine extends Vehicle {

	public Limousine(String brand, String serial) {
		super(brand, serial);
	}

	@Override
	public void printICar() {
		System.out.println(this.getClass().getSimpleName() + " " + getBrand() + " " + getSerial());
	}
}