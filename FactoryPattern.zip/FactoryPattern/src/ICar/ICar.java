package ICar;

public interface ICar {

	String getBrand();

	String getSerial();

	void printICar();
}
