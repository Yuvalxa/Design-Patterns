package ICar;

final public class SUV extends Vehicle {

	public SUV(String brand, String serial) {
		super(brand, serial);
	}

	@Override
	public void printICar() {
		System.out.println(this.getClass().getSimpleName() + " " + getBrand() + " " + getSerial());
	}
}