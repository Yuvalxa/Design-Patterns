module FactoryPattern {
}