/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public class Main {

	public static void main(String[] args) {
		ABC a;
		ABC b;
		ABC c;
		LetterFactory fac= new LetterFactory();
		Letter A = fac.getLetter("a");
		System.out.println(A);
		Letter B = fac.getLetter("b");
		System.out.println(B);
		Letter C = fac.getLetter("c");
		System.out.println(C);

		a = new Aa();
		a.printABC();
		b = new Bb();
		b.printABC();
		c = new Cc();
		c.printABC();

	}

}
