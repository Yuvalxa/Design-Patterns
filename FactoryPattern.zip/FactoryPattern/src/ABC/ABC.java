/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public interface ABC {
	void printABC();
}
