/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public class Cc extends C implements ABC {
	private String smallSymbol;

	public Cc() {
		this.smallSymbol = "c";
	}

	public String getSymbol() {
		return smallSymbol;
	}

	public void setValue(String bigSymbol) {
		this.smallSymbol = bigSymbol;
	}

	@Override
	public String toString() {
		return super.getSymbol() + getSymbol();
	}

	@Override
	public void printABC() {
		System.out.println(this);
	}

}