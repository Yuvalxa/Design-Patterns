package ABC;

public class LetterFactory {
	public Letter getLetter(String letter,int num) {
		if(letter == null) return null;
		if(letter.equalsIgnoreCase("a")) {
			A a =new A();
			for (int i = 0; i < num; i++) {
				a.addletter(letter);
			}
		}
		else if(letter.equalsIgnoreCase("b")) return new B();
		else if(letter.equalsIgnoreCase("c")) return new C();
		else return null;

	}
}
