package ABC;

public interface Letter {
	void addletter(String letter);
}
