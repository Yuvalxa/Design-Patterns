/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public class B implements ABC,Letter {
	private String bigSymbol;

	public B() {
		this.bigSymbol = "B";
	}

	public String getSymbol() {
		return bigSymbol;
	}

	public void setValue(String bigSymbol) {
		this.bigSymbol = bigSymbol;
	}

	@Override
	public String toString() {
		return bigSymbol;
	}

	@Override
	public void printABC() {
		System.out.println(this);
	}

	@Override
	public void addletter(String letter) {

		this.bigSymbol+="letter";
	}

}