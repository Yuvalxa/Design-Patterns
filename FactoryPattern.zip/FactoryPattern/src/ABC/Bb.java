/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public class Bb extends B implements ABC {
	private String smallSymbol;

	public Bb() {
		this.smallSymbol = "b";
	}

	public String getSymbol() {
		return smallSymbol;
	}

	public void setValue(String bigSymbol) {
		this.smallSymbol = bigSymbol;
	}

	@Override
	public String toString() {
		return super.getSymbol() + getSymbol();
	}

	@Override
	public void printABC() {
		System.out.println(this);
	}

}