/**
 * @author GRIGORY SHAULOV
 */
package ABC;

public class A implements ABC,Letter {
	private String bigSymbol;

	public A() {
		this.bigSymbol = "A";
	}

	public String getSymbol() {
		return bigSymbol;
	}

	public void setValue(String bigSymbol) {
		this.bigSymbol = bigSymbol;
	}

	@Override
	public String toString() {
		return bigSymbol;
	}

	@Override
	public void printABC() {
		System.out.println(this);
	}

	@Override
	public void addletter(String letter) {
		this.bigSymbol+=letter;
	}

}