package AdapterPatternABC;

public class B implements Bprintable {

	@Override
	public void printB() {
		System.out.println("B");
		
	}

}
