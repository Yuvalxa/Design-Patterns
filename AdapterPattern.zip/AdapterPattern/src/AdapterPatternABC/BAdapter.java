package AdapterPatternABC;

public class BAdapter implements Aprintable{
	Bprintable bPrintable;

	public BAdapter(Bprintable bPrintable) {
		this.bPrintable = bPrintable;
	}

	@Override
	public void printA() {
		bPrintable.printB();
	}
}
