package AdapterPatternABC;

public class ABC {
	private Aprintable a;

	public ABC(Aprintable a) {
		this.a = a;
	}

	void printA() {
		a.printA();
	}
}
