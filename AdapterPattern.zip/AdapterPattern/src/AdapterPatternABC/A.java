package AdapterPatternABC;

public class A implements Aprintable{

	@Override
	public void printA() {
		System.out.println("a");		
	}

}
