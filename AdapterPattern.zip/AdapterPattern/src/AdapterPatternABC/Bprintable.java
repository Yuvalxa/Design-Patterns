package AdapterPatternABC;

public interface Bprintable {
void printB();
}
