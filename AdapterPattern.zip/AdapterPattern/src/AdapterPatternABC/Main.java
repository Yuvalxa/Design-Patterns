package AdapterPatternABC;

public class Main {
	public static void main(String[] args) {
		ABC abc = new ABC(new A());
		abc.printA();
		Bprintable b = new B();
		BAdapter adapter = new BAdapter(b);
		abc = new ABC(adapter);
		abc.printA();
	}

}
