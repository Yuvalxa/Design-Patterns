package AdapterPatternABC;

public interface Aprintable {
void printA();
}
