package AdaperPhones;
public class IPhoneWhiteCable implements IPhoneCable {
	@Override
	public void connectToIPhone(IPhone iphone) {
		System.out.println("IPhone Cable connected to " + iphone.getName());
		iphone.chargeIPhone();
	}
}
