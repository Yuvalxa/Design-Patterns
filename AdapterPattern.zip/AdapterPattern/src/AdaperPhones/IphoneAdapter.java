package AdaperPhones;

public class IphoneAdapter implements SamsungCable{
private IPhoneCable cable;
	@Override
	public void connectToSamsung(Samsung samsung) {
		cable.connectToIPhone(samsung);		
	}

}
