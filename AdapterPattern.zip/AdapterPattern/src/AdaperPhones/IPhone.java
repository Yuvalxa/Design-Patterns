package AdaperPhones;
public interface IPhone {
	String getName();
	void chargeIPhone();
}
