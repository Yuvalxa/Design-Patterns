package AdaperPhones;
public interface SamsungCable {
	void connectToSamsung(Samsung samsung);
}
