package AdaperPhones;
public class IPhoneX implements IPhone {
	@Override
	public String getName() {
		return "IPhoneX";
	}

	@Override
	public void chargeIPhone() {
		System.out.println(getName() + " is charging...");
	}
}