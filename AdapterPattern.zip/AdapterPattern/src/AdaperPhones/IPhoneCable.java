package AdaperPhones;
public interface IPhoneCable {
	void connectToIPhone(IPhone iphone);
}
