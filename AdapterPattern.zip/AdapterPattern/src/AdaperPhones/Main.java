package AdaperPhones;
public class Main {
	public static void main(String[] args) {
		// Iphone cable connected to iphone
		IPhone iphoneX = new IPhoneX();
		IPhoneCable iphoneCable = new IPhoneWhiteCable();
		iphoneCable.connectToIPhone(iphoneX);
		System.out.println();
		
		Samsung samsungS9 = new SamsungS9();
		SamsungCable samsungCable = new SamsungBlackCable();
		samsungCable.connectToSamsung(samsungS9);
		System.out.println();
	}
}
