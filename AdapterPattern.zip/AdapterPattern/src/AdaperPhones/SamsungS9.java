package AdaperPhones;
public class SamsungS9 implements Samsung {
	@Override
	public String getName() {
		return "SamsungS9";
	}

	@Override
	public void chargeSamsung() {
		System.out.println(getName() + " is charging...");
	}
}
