package AdaperPhones;
public class SamsungBlackCable implements SamsungCable {
	@Override
	public void connectToSamsung(Samsung samsung) {
		System.out.println("Samsung Cable connected to " + samsung.getName());
		samsung.chargeSamsung();
	}
}