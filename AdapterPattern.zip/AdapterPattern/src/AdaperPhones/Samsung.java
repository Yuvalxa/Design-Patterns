package AdaperPhones;
public interface Samsung {
	String getName();

	void chargeSamsung();
}
