module AdapterPattern {
}