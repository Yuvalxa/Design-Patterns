package decorator.car.ce;

/**
 * @author GRIGORY SHAULOV
 */

final public class Limousine extends Vehicle {

	public Limousine(String brand, String serial) {
		super(brand, serial);
	}
	@Override
	public String addDecorate() {
		return this.toString();
	}
}