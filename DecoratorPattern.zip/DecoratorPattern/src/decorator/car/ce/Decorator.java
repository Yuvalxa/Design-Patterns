package decorator.car.ce;

public interface Decorator {
	String addDecorate();

}
