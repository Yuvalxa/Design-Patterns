package decorator.car.ce;

/**
 * @author GRIGORY SHAULOV
 */

final public class Minibus extends Vehicle {

	public Minibus(String brand, String serial) {
		super(brand, serial);
	}
	@Override
	public String addDecorate() {
		return this.toString();
	}
}