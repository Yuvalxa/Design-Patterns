package decorator.car.ce;

/**
 * @author GRIGORY SHAULOV
 */

final public class Sedan extends Vehicle {

	public Sedan(String brand, String serial) {
		super(brand, serial);
	}
	@Override
	public String addDecorate() {
		return this.toString();
	}
}