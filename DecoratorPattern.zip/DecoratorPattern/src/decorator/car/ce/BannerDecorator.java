package decorator.car.ce;

public class BannerDecorator  extends VechicleDecorator{

	public BannerDecorator(Decorator vdectorator) {
		super(vdectorator);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String addDecorate() {
		// TODO Auto-generated method stub
		return addDecorate();
	}

}
