package decorator.car.ce;

/**
 * @author GRIGORY SHAULOV
 */

final public class SUV extends Vehicle {

	public SUV(String brand, String serial) {
		super(brand, serial);
	}
	@Override
	public String addDecorate() {
		return this.toString();
	}
}