package decorator.car.ce;

public abstract class VechicleDecorator implements Decorator {
	protected Decorator vdectorator;

	public VechicleDecorator(Decorator vdectorator) {
		this.vdectorator = vdectorator;
	}

	@Override
	public String toString() {
		return "VechicleDecorator [vdectorator=" + vdectorator + "]";
	}

}
