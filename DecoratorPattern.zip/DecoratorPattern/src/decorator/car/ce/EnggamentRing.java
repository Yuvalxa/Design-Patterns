package decorator.car.ce;

public class EnggamentRing extends VechicleDecorator{

	public EnggamentRing(Decorator vdectorator) {
		super(vdectorator);
	}
	public String toString() {
		// TODO Auto-generated method stub
		return this.vdectorator.toString()+"Engament Ring On your Finnnngger biatch";
	}
	@Override
	public String addDecorate() {
		// TODO Auto-generated method stub
		return addDecorate();
	}

}
