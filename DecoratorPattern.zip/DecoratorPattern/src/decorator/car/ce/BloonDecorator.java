package decorator.car.ce;

public class BloonDecorator extends VechicleDecorator{

	public BloonDecorator(Decorator vdectorator) {
		super(vdectorator);
	}
	public String toString() {
		// TODO Auto-generated method stub
		return this.vdectorator.toString()+"Baloon On TOP";
	}
	@Override
	public String addDecorate() {
		// TODO Auto-generated method stub
		return addDecorate();
	}

}
