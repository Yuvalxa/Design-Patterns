module DecoratorPattern {
}