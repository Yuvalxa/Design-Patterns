package ABCx;

public class ComaABCDecorator extends ABCDecorator {

	public ComaABCDecorator(ABC decorateABC) {
		super(decorateABC);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.decorateABC.toString()+ ",";
	}
	@Override
	public String printValue() {
		return printValue();
	}

}
