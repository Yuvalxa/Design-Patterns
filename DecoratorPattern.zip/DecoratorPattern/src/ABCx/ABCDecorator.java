package ABCx;

public abstract class ABCDecorator implements ABC {
	protected ABC decorateABC;

	public ABCDecorator(ABC decorateABC) {
		this.decorateABC = decorateABC;
	}
	

}
