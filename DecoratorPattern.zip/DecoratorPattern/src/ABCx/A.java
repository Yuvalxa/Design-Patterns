package ABCx;
/**
 * @author GRIGORY SHAULOV
 */
public class A implements ABC{
	private String value;

	public A() {
		this.value = "A";
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return value;
	}

	@Override
	public String printValue() {
		return this.toString();
	}

}