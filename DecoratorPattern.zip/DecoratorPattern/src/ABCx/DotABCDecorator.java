package ABCx;

public class DotABCDecorator extends ABCDecorator {

	public DotABCDecorator(ABC decorateABC) {
		super(decorateABC);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.decorateABC.toString()+ ".";
	}
	@Override
	public String printValue() {
		return printValue();
	}
}
