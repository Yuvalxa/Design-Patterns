package ABCx;

public interface ABC {
String printValue();
}
