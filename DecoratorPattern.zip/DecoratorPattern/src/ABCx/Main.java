package ABCx;
/**
 * @author GRIGORY SHAULOV
 */
public class Main {

	public static void main(String[] args) {
		A a = new A();
		B b = new B();
		System.out.println(a);
		System.out.println(b);
		DotABCDecorator dec1= new DotABCDecorator(a);
		System.out.println(new DotABCDecorator(new DotABCDecorator(a)));
		System.out.println(new DotABCDecorator(new DotABCDecorator(b)));

	}

}
